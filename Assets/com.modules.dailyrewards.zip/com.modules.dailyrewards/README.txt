Please, check the Documentation.pdf or the online version at https://goo.gl/q3CwzF

Enjoy and don't forget to rate!