public enum MultiTags
{
	Tag1,
	Tag2,
	Tag3,
}
