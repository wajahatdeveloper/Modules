using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading.Tasks;
using Sirenix.OdinInspector;
using UnityEngine;

namespace DataLayer
{
    /// <summary>
    /// This is the data that is mirrored locally and on the network
    /// </summary>
    public class MirroredData : SingletonBehaviour<MirroredData>
    {
        private const string LogClassName = "MirroredData";

        [ShowInInspector, ReadOnly] private bool isInMatch = false;
        [ShowInInspector, ReadOnly] private int killCount = 0;
        [ShowInInspector, ReadOnly] private string playerNickName = "";

        public bool GetIsInMatch() => isInMatch;
        public void SetIsInMatch(bool value)
        {
            isInMatch = value;
            NetworkData.Instance.SendToDatabaseAsync("IsInMatch",value);
        }

        public async Task<bool> GetIsInMatchRealtimeAsync()
        {
            var val = await NetworkData.Instance.FetchFromDatabase("IsInMatch", false);
            return bool.Parse(val.ToString());
        }

        public string GetPlayerNickName()
        {
            if (playerNickName == "")
            {
                playerNickName = DefaultData.Instance.GenerateRandomGuestName();
            }
            return playerNickName;
        }

        public void SetPlayerNickName(string nickName)
        {
            playerNickName = nickName;
            NetworkData.Instance.SendToDatabaseAsync("NickName",nickName);
        }

        private event Action<int> killCountUpdateAction;

        public void SetKillCount(int value)
        {
            this.killCount = value;
            NetworkData.Instance.SendToDatabaseAsync("KillCount",value);
            killCountUpdateAction?.Invoke(value);
        }

        public int GetKillCount()
        {
            return killCount;
        }

        public void SubscribeToKillCountUpdates(Action<int> handler)
        {
            killCountUpdateAction += handler;
        }

        public void UnsubscribeToKillCountUpdates(Action<int> handler)
        {
            killCountUpdateAction -= handler;
        }
    }
}