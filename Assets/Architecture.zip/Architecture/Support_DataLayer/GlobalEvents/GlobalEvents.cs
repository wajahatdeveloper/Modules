using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.Events;

public static class GlobalEvents
{
    public static Action OnShowRoomLobby;
    public static Action<string> OnEnableRejoin;    // room id
    public static Action OnDisableRejoin;
}