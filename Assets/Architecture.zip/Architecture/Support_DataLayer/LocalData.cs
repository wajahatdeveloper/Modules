using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading.Tasks;
using Sirenix.OdinInspector;
using UnityEngine;

namespace DataLayer
{
    /// <summary>
    /// This is the data that is stored only locally
    /// </summary>
    public class LocalData : SingletonBehaviour<LocalData>
    {
        private const string LogClassName = "LocalData";

        [ReadOnly] public string SelectedMapName;
        [ReadOnly] public string SelectedModeName;

        [ReadOnly] public string PrivateRoomPassKey;
        [ReadOnly] public bool IsPrivateLobbyUsed;

        [ReadOnly] public bool IsPlayerRejoining = false;

        [ShowInInspector, ReadOnly] private int inGameScore;

        public int GetInGameScore() => inGameScore;
        public void SetInGameScore(int value) => this.inGameScore = value;

        public string GetPlayerUserId_Persistent()
        {
            return PersistentDataHandler.GetData<string>("PlayerUserId", "");
        }

        public void SetPlayerUserId_Persistent(string value) => PersistentDataHandler.SetData("PlayerUserId", value);


        public bool GetIsRejoinAvailable_Persistent() => PersistentDataHandler.GetData<bool>("IsRejoinAvailable", false);
        public void SetIsRejoinAvailable_Persistent(bool value) => PersistentDataHandler.SetData("IsRejoinAvailable", value);

        public string GetRejoinRoomId_Persistent() => PersistentDataHandler.GetData<string>("RejoinRoomId", "");
        public void SetRejoinRoomId_Persistent(string value) => PersistentDataHandler.SetData("RejoinRoomId", value);

        public int GetCurrentModeMinimumPlayerCount()
        {
            return SelectedModeName == DefaultData.Instance.gameSettings.mode1Name ?
                DefaultData.Instance.gameSettings.minimumPlayersInMode1 :
                DefaultData.Instance.gameSettings.minimumPlayersInMode2;
        }

        public int GetCurrentModeMaximumPlayerCount()
        {
            return SelectedModeName == DefaultData.Instance.gameSettings.mode1Name ?
                DefaultData.Instance.gameSettings.maximumPlayersInMode1 :
                DefaultData.Instance.gameSettings.maximumPlayersInMode2;
        }
    }
}