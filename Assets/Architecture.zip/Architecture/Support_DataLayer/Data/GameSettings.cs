﻿using UnityEngine;

namespace DataLayer
{
    [CreateAssetMenu(fileName = "GameSettings", menuName = "Custom/GameSettings")]
    public class GameSettings : ScriptableObject
    {
        [Header("Room")]
        public string defaultRoomName = "defaultRoom";
        public string roomPrefix = "Room_";
        public bool randomizeDefaultRoomName = true;
        [Range(3,16)] public int randomDefaultRoomDigits = 6;

        [Header("Player")]
        public int guestNameIdRangeMin = 11111;
        public int guestNameIdRangeMax = 99999;

        [Header("Match (Mode 1)")] // High Score Mode
        public string mode1Name = "Mode1";
        [Range(1,20)] public int minimumPlayersInMode1 = 2;
        [Range(1,20)] public int maximumPlayersInMode1 = 7;    // 20 CCU Max PUN2 Free Tier
        public int matchTimeInSeconds = 160;    // Two Minutes and Thirty Seconds

        [Header("Match (Mode 2)")]      // Battle Royale Mode
        public string mode2Name = "Mode2";
        [Range(1,20)] public int minimumPlayersInMode2 = 2;
        [Range(1,20)] public int maximumPlayersInMode2 = 20;    // 20 CCU Max PUN2 Free Tier

        [Header("General Match Settings")]
        public RejoinSetting rejoinSetting = RejoinSetting.AutoRejoin;

        [Header("Leaderboard (InGame)")]
        [Range(1,25)]
        public int inGameLeaderboardEntities = 3;
    }

    public enum RejoinSetting
    {
        NoRejoin = 0,
        AutoRejoin = 1,
        ManualRejoin = 2,
    }
}