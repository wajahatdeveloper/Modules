using System.Collections;
using System.Collections.Generic;
using System.Threading.Tasks;
using Firebase.Database;
using Sirenix.OdinInspector;
using UnityEngine;

namespace DataLayer
{
    /// <summary>
    /// This is the data that is stored on the network only
    /// </summary>
    public partial class NetworkData : SingletonBehaviour<NetworkData>
    {
        private const string LogClassName = "NetworkData";

        public void SetPlayerUserId(string value)
        {
            LocalData.Instance.SetPlayerUserId_Persistent(value);
            SendToDatabaseAsync("userId",value);
        }

        public async Task<string> GetPlayerUserIdAsync()
        {
            string playerUserId = (string) await FetchFromDatabase("userId", "");
            LocalData.Instance.SetPlayerUserId_Persistent(playerUserId);
            return playerUserId;
        }

        public void SetIsEaten(bool isEaten)
        {
            var playerProps = new ExitGames.Client.Photon.Hashtable { { "IsEaten" , isEaten } };
            PUNRoomHandler.SetLocalPlayerProperties(playerProps);
        }

        public bool GetIsEaten()
        {
            return (bool) PUNRoomHandler.GetLocalPlayerProperty("IsEaten" , false);
        }
    }
}