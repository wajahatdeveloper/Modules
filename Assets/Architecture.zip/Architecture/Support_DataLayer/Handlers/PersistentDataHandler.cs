using System;
using System.Collections.Generic;
using System.IO;
using com.kupio.declarativeorder;
using Newtonsoft.Json;
using UnityEngine;

namespace DataLayer
{
    [RunFirst]
    internal class PersistentDataHandler : MonoBehaviour
    {
        private static Dictionary<string, object> dataDictionary = new();
        private static string dataFilePath = "";
        private static bool isDirty = false;

        private void OnEnable()
        {
            dataFilePath = Application.persistentDataPath + "/gameData.json";

#if UNITY_EDITOR
            dataFilePath =  Application.persistentDataPath + $"/gameData_{MultiPlay.Utils.GetCurrentCloneIndex()}.json";
#endif

            PersistentDataHandler.LoadData();
        }

        public static void DeleteDataFile()
        {
            File.Delete(dataFilePath);
        }

        private void OnApplicationFocus(bool pauseStatus)
        {
            if (pauseStatus)
            {
                PersistentDataHandler.SaveData();
            }
        }

        private void OnApplicationQuit()
        {
            PersistentDataHandler.SaveData();
        }

        public static void SaveData()
        {
            if (!isDirty) { return; }
            Debug.Log("Saving Persistent Data To File");
            string jsonData = JsonConvert.SerializeObject(dataDictionary);
            File.WriteAllText(dataFilePath, jsonData);
        }

        public static void LoadData()
        {
            if (File.Exists(dataFilePath))
            {
                Debug.Log("Loading Persistent Data From File");
                string jsonData = File.ReadAllText(dataFilePath);
                dataDictionary = JsonConvert.DeserializeObject<Dictionary<string, object>>(jsonData);
            }
            else
            {
                dataDictionary = new Dictionary<string, object>();
            }
        }

        public static void SetData(string key, object value)
        {
            if (dataDictionary.ContainsKey(key))
            {
                dataDictionary[key] = value;
            }
            else
            {
                dataDictionary.Add(key, value);
            }

            isDirty = true;
        }

        public static T GetData<T>(string key, T defaultValue = default)
        {
            if (dataDictionary.ContainsKey(key))
            {
                try
                {
                    return (T)dataDictionary[key];
                }
                catch (InvalidCastException)
                {
                    Debug.LogError($"Failed to cast data with key '{key}' to type {typeof(T)}");
                }
            }

            return defaultValue;
        }
    }
}