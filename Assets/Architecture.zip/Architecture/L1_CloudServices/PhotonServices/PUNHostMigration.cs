using System;
using System.Collections;
using System.Collections.Generic;
using Photon.Pun;
using Photon.Realtime;
using Sirenix.OdinInspector;
using UnityEngine;

[InfoBox("This Script Exposes the Following Events\n" +
         "OnHostMigrated<Player>")]
public class PUNHostMigration : MonoBehaviourPunCallbacks
{
    private const string LogClassName = "PUNHostMigration";

    public static event Action<Player> OnHostMigrated;
    
    public override void OnMasterClientSwitched(Player newMasterClient)
    {
        DebugX.Log($"{LogClassName} : Master Client Switched to {newMasterClient.NickName}", LogFilters.Network, gameObject);

        OnHostMigrated?.Invoke(newMasterClient);
    }
}