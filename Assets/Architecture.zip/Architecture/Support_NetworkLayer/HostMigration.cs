using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using DataLayer;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine;

/// <summary>
/// This Gameplay Module Confirms all the Players Status After Host Migration.
/// </summary>
public class HostMigration : MonoBehaviourPunCallbacks
{
    private const string LogClassName = "HostMigration";

    private Dictionary<Player, bool> pingReceivedMap = new();

    public override void OnEnable()
    {
        base.OnEnable();
        PUNHostMigration.OnHostMigrated += Handle_OnHostMigrated;
    }

    public override void OnDisable()
    {
        base.OnDisable();
        PUNHostMigration.OnHostMigrated -= Handle_OnHostMigrated;
    }
    
    private void Handle_OnHostMigrated(Player newMasterClient)
    {
        // must be the new master client to handle
        if (!PhotonNetwork.IsMasterClient) { return; }
        
        DebugX.Log($"{LogClassName} : Host Migrated : Pinging all Players..", LogFilters.None, gameObject);

        pingReceivedMap.Clear();
        foreach (Player player in PhotonNetwork.CurrentRoom.Players.Values)
        {
            pingReceivedMap.Add(player, false);
        }
        
        photonView.RPC(nameof(RPC_Ping),RpcTarget.AllViaServer);
        
        this.Invoke(() =>
        {
            // must still be master client (after the delay)
            if (!PhotonNetwork.IsMasterClient) { return; }

            // Update the disconnected ones
            var nonResponseList = pingReceivedMap.Where(x => x.Value == false).ToList();
            foreach (var playerEntry in nonResponseList)
            {
                MakePlayerDisconnected(playerEntry.Key);
            }
        },6.0f);
    }

    [PunRPC]
    public void RPC_Ping()
    {
        if (PhotonNetwork.LocalPlayer.IsInactive)
        {
            DebugX.Log($"{LogClassName} : Player self is inactive (Ping Response Skipped)..", LogFilters.None, gameObject);
            return;
        }
        
        // Respond to the Ping By Sending the Response RPC to Master Client
        photonView.RPC(nameof(RPC_PingResponse),RpcTarget.MasterClient, PhotonNetwork.LocalPlayer.ActorNumber);
    }
    
    [PunRPC]
    public async void RPC_PingResponse(int actorId)
    {
        Player player = PhotonNetwork.CurrentRoom.GetPlayer(actorId);

        pingReceivedMap[player] = true;
        
        if (player.IsInactive)
        {
            DebugX.Log($"{LogClassName} : Player {player.NickName} is inactive.", LogFilters.None, gameObject);
            return;
        }
        
        // The Player is present in the match (since the response is received)
        // Check the status of this player in database and fix accordingly
        var status = await NetworkData.Instance.GetRoomPlayerStatus(player.UserId,
            PhotonNetwork.CurrentRoom.Name, NetworkData.RoomKeyPlayerStatus.Disconnected);

        switch (status)
        {
            case NetworkData.RoomKeyPlayerStatus.UnAvailable:
                DebugX.Log($"{LogClassName} : Player {player.NickName} UnAvailable => Present.", LogFilters.None, gameObject);
                MakePlayerPresent(player);
                break;
            
            case NetworkData.RoomKeyPlayerStatus.Left:
                Debug.LogError("This should not happen!");
                break;

            case NetworkData.RoomKeyPlayerStatus.Disconnected:
                DebugX.Log($"{LogClassName} : Player {player.NickName} Disconnected => Present.", LogFilters.None, gameObject);
                MakePlayerPresent(player);
                break;
            
            case NetworkData.RoomKeyPlayerStatus.Present:
                DebugX.Log($"{LogClassName} : Player {player.NickName} is present in match.", LogFilters.None, gameObject);
                break;
            
            default:
                throw new ArgumentOutOfRangeException();
        }
    }

    private void MakePlayerPresent(Player player)
    {
        NetworkData.Instance.SetRoomPlayerStatus(player.UserId, PhotonNetwork.CurrentRoom.Name,
            NetworkData.RoomKeyPlayerStatus.Present);
    }
    
    private async void MakePlayerDisconnected(Player player)
    {
        // The Player is not present in the match (since the response is timed out)
        // Check the status of this player in database and fix accordingly
        var status = await NetworkData.Instance.GetRoomPlayerStatus(player.UserId,
            PhotonNetwork.CurrentRoom.Name, NetworkData.RoomKeyPlayerStatus.UnAvailable);

        switch (status)
        {
            case NetworkData.RoomKeyPlayerStatus.Left:
            case NetworkData.RoomKeyPlayerStatus.Disconnected:
                // Do Nothing
                break;
            
            case NetworkData.RoomKeyPlayerStatus.UnAvailable:
            case NetworkData.RoomKeyPlayerStatus.Present:
                DebugX.Log($"{LogClassName} : Player {player.NickName} Present => Disconnected.", LogFilters.None, gameObject);
                NetworkData.Instance.SetRoomPlayerStatus(player.UserId, PhotonNetwork.CurrentRoom.Name,
                    NetworkData.RoomKeyPlayerStatus.Disconnected);
                break;
            
            default:
                throw new ArgumentOutOfRangeException();
        }
    }
}