﻿namespace QFSW.QC.Actions
{
    /// <summary>
    /// Waits until the next frame.
    /// </summary>
    public class WaitFrame : WaitRealtime
    {
        public WaitFrame() : base(0)
        {

        }
    }
}